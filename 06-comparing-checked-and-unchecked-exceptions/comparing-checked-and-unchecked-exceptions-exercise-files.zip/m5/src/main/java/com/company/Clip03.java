package com.company;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Example of UncheckedIOException
 *
 */
public class Clip03
{
    public static void main( String[] args ) throws IOException
    {
        processFile("c:\\file.txt");
    }

    private static void processFile(String path) throws IOException {
        Files.lines(Paths.get(path))
                .forEach(line -> processData(line));
    }

    private static void processData(String l) {
        try {
            throw new IOException();
        } catch (IOException ioe) {
            throw new UncheckedIOException(ioe);
        }
    }
}
