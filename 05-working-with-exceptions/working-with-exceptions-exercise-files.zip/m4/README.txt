To import the project in Eclipse:
1. File -> Import
2. Existing Maven Project
3. Navigate to the project's directory
4. Select the pom.xml file and click Finish

To import the project in IntelliJ IDEA
1. In the Welcome to IntelliJ IDEA window, choose the option Open
2. Select the project's directory pom.xml file and click Ok
3. Choose the option Open as a Project

URLs:
The Java® Language Specification 11.2
http://bit.ly/jls11-2

The Java® Language Specification 14.20.2
http://bit.ly/jls14-20-2


Java Documentation
https://docs.oracle.com/javase/8/docs/api/java/lang/AutoCloseable.html
https://docs.oracle.com/javase/8/docs/api/java/io/Closeable.html