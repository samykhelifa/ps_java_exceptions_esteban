﻿To import the project in Eclipse:
1. File -> Import
2. Existing Maven Project
3. Navigate to the project's directory
4. Select the pom.xml file and click Finish

To import the project in IntelliJ IDEA
1. In the Welcome to IntelliJ IDEA window, choose the option Open
2. Select the project's directory pom.xml file and click Ok
3. Choose the option Open as a Project

URLs:
Creating Exception Classes
http://bit.ly/creatingExceptions

Effective Java Exceptions
http://bit.ly/effectiveJavaExceptions
